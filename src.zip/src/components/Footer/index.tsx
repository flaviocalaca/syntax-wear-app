import IconInstagram from "@/assets/images/icon-instagram.png";
import IconFacebook from "@/assets/images/icon-facebook.png";
import IconTictok from "@/assets/images/icon-tictok.png";
import IconWhatsapp from "@/assets/images/icon-whatsapp.png";

const socialLinks = [
  { href: "#", icon: IconInstagram, name: "Instagram" },
  { href: "#", icon: IconFacebook, name: "Facebook" },
  { href: "#", icon: IconTictok, name: "Tictok" },
  { href: "#", icon: IconWhatsapp, name: "Whatsapp" },
];

export const Footer = () => {
  return (
    <footer className="bg-footer-bg">
      <div className="container">
        <div>
          <form action="" className="flex flex-col">
            <label htmlFor="newslatter">Insira seu e-mail</label>
            <input
              type="email"
              id="newslatter"
              name="newsletter"
              placeholder="email@email.com"
              className="rounded-[30px] bg-white py-3 px-5"
            />
          </form>

        </div>
      </div>
    </footer>
  );
};
