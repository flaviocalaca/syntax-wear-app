import { Button } from "../Button";

export const CEPForm = () => {
  return (
    <form className="flex gap-3">
      <input
        type="text"
        placeholder="digite seu CEP"
        className="border border-[#c0c0c0] rounded-md p-3"
      />
      <Button variant="primary" size="lg">
        Calcular
      </Button>
    </form>
  );
};

